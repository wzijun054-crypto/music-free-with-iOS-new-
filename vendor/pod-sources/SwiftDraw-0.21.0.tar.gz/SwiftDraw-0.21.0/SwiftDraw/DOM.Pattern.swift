//
//  DOM.Pattern.swift
//  SwiftDraw
//
//  Created by Simon Whitty on 26/3/19.
//  Copyright 2020 Simon Whitty
//
//  Distributed under the permissive zlib license
//  Get the latest version from here:
//
//  https://github.com/swhitty/SwiftDraw
//
//  This software is provided 'as-is', without any express or implied
//  warranty.  In no event will the authors be held liable for any damages
//  arising from the use of this software.
//
//  Permission is granted to anyone to use this software for any purpose,
//  including commercial applications, and to alter it and redistribute it
//  freely, subject to the following restrictions:
//
//  1. The origin of this software must not be misrepresented; you must not
//  claim that you wrote the original software. If you use this software
//  in a product, an acknowledgment in the product documentation would be
//  appreciated but is not required.
//
//  2. Altered source versions must be plainly marked as such, and must not be
//  misrepresented as being the original software.
//
//  3. This notice may not be removed or altered from any source distribution.
//

import Foundation

extension DOM {
    
    struct Pattern: ContainerElement {
        
        var id: String
        var x: Coordinate?
        var y: Coordinate?
        var width: Coordinate
        var height: Coordinate
        
        var patternUnits: Units?
        var patternContentUnits: Units?
        
        var childElements: [DOM.GraphicsElement] = []
        
        init(id: String, width: Coordinate, height: Coordinate) {
            self.id = id
            self.width = width
            self.height = height
        }
    }
}

extension DOM.Pattern {
    
    enum Units: String {
        case userSpaceOnUse
        case objectBoundingBox
    }
}
